<?php
/*
Name: Soliloquy
Description: Soliloquy is the best responsive WordPress slider plugin. Period.
Author: Thomas Griffin
Author URI: http://thomasgriffinmedia.com/
Version: 1.0.1
License: GNU General Public License v2.0 or later
License URI: http://www.opensource.org/licenses/gpl-license.php
Class: soliloquy_thesis_box
*/

/*
	Copyright 2012	 Thomas Griffin	 (email : thomas@thomasgriffinmedia.com)

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License, version 2, as
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/**
 * Inherited class for the Soliloquy Box for Thesis 2.
 *
 * @since 1.0.0
 *
 * @package	Soliloquy Box
 * @author	Thomas Griffin
 */
class soliloquy_thesis_box extends thesis_box {

	/**
	 * Class constructor.
	 *
	 * @since 1.0.0
	 */
	protected function construct() {

		/** Remove meta boxes from the Soliloquy screen */
		add_action( 'add_meta_boxes', array( $this, 'remove_meta_boxes' ), 100 );

	}

	/**
	 * Removes all of the Thesis meta boxes from the Soliloquy add/edit screen.
	 *
	 * @since 1.0.0
	 *
	 * @global object $thesis The global Thesis object
	 * @return null Return early if not on the Soliloquy add/edit screen
	 */
	public function remove_meta_boxes() {

		global $thesis;

		/** Return early if not on the Soliloquy add/edit screen */
		if ( ! Tgmsp::is_soliloquy_add_edit_screen() )
			return;

		/** Remove all meta boxes from view */
		foreach ( $thesis->wp->post_meta as $class => $data )
			remove_meta_box( $class, convert_to_screen( 'soliloquy' ), isset( $data['context'] ) ? $data['context'] : 'normal' );

	}

	/**
	 * Send translatable strings to the parent method for outputting.
	 *
	 * @since 1.0.0
	 */
	protected function translate() {

		/** Load our box textdomain for localization support */
		load_plugin_textdomain( 'soliloquy-box', false, dirname( __FILE__ ) . '/languages/' );

		/** Load our name strings into the API */
		$this->title = $this->name = __( 'Soliloquy', 'soliloquy-box' );

	}

	/**
	 * Load our options into the Thesis Box API for outputting.
	 *
	 * @since 1.0.0
	 *
	 * @return array $options Array of options for the Soliloquy Box
	 */
	protected function html_options() {

		/** Prepare our options array for the select box */
		$opts		= array();
		$sliders 	= Tgmsp::get_sliders();

		/** Loop through the available sliders and store the data for our options */
		foreach ( (array) $sliders as $slider )
			$opts[absint( $slider->ID )] = esc_attr( $slider->post_title );

		/** Return our options */
		return array(
			'soliloquy' => array(
				'type' 		=> 'select',
				'label' 	=> __( 'Select Your Soliloquy Slider', 'soliloquy-box' ),
				'options'	=> $opts,
				'tooltip' 	=> __( 'Select a slider from the list of available sliders below to insert into your content.', 'soliloquy-box' )
			)
		);

	}

	/**
	 * Output the HTML for the sliders.
	 *
	 * @since 1.0.0
	 */
	public function html() {

		if ( isset( $this->options['soliloquy'] ) && ! empty( $this->options['soliloquy'] ) )
			if ( function_exists( 'soliloquy_slider' ) )
				soliloquy_slider( absint( $this->options['soliloquy'] ) );

	}

}